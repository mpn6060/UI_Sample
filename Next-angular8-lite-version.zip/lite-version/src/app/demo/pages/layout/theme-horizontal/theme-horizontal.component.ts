import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-theme-horizontal',
  templateUrl: './theme-horizontal.component.html',
  styleUrls: ['./theme-horizontal.component.scss']
})
export class ThemeHorizontalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
