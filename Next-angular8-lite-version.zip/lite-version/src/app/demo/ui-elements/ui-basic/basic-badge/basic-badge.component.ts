import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-badge',
  templateUrl: './basic-badge.component.html',
  styleUrls: ['./basic-badge.component.scss']
})
export class BasicBadgeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
